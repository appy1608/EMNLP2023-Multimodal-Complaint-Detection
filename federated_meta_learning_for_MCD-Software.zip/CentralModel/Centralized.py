"""
Name: Centralized.py
Date: Nov 2021
Centralized setting MCI training
"""

# Import necessary inbuilt libraries
import pandas as pd
import torch
from torch import optim
import torchvision.transforms as T
from PIL import Image
import warnings
import numpy as np
import json
import os.path
from sklearn.metrics import classification_report
from iteration_utilities import deepflatten
import random
random.seed(7)

# Import user-defined libraries
from CentralModel import IamEncoder

warnings.filterwarnings("ignore")
device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

with torch.no_grad():
    torch.cuda.empty_cache()

print('Utilizing', torch.cuda.get_device_name(0), '...')

# Load hyper-parameters from config.json file
with open("config.json") as json_data_file:
    data = json.load(json_data_file)

print('Loading the config.json file ...')

epochs = data[ "epochs"]
lr = data[ "lr"]
lstm_hidden_size = data["lstm_hidden_size"]
file_name = data["file_name"]
num_layers = data['num_layers']
att_size = data['att_size']
batch_size = data['batch_size']
shall_i_sent = data['shall_i_sent']
shall_i_emot = data['shall_i_emot']

input_size = 768

def get_me_the_images(indexes):
    """
    Returns the corresponding images
    :param indexes: indexes to select input
    :return : corresponding images
    """
    imgs = []
    for i in indexes:
        try:
            img_name = df1['ImageURL'][i].split('/')[-1]
            img = Image.open('path/Combined_Dataset/Images/' + img_name)
            resized_imgs = T.ToTensor()(T.Resize((224,224))(img))
        except:
            resized_imgs = torch.zeros((3, 224, 224))
        imgs.append(resized_imgs)
    imgs = torch.stack(imgs)
    return imgs


def get_train_index(path = 'path/Code/I5/Indexes/train.txt'):
    with open(path, 'r') as file:
        data = file.read()
    data = data[1:-1]
    product = data.split('\', \'')
    train_ind = []
    for p in product:
        df2 = df1.loc[df1['Product'] == p]
        train_ind.append(df2.index.tolist())
    return train_ind

def get_valid_test_index(path):
    with open(path, 'r') as file:
        data = file.read()

    data = data[2:-2]
    ind = data.split(', ')
    vt_ind = [int(i) for i in ind]
    return vt_ind

if os.path.isfile(file_name):
            
    with open(file_name, 'a') as f: 
        f.write('\n')
        f.write('-' * 20)
        f.write('\n')
        for key, value in data.items(): 
            f.write('%s:%s\n' % (key, value))
        f.write('\n')
            

    # Load the main DataFrame
    df1 = pd.read_csv('path/Combined_Dataset/Combined.csv')

    # Load the embedded files
    print('Loading Embedded Vectors ...')
    reviews = torch.load('path/Embedded/ReviewEmbeddedV2.pt')
    titles = torch.load('path/Embedded/TitleEmbedded2.pt')

    valid_ind = get_valid_test_index('path/Code/I5/Indexes/valid.txt')
    test_ind = get_valid_test_index('path/Code/I5/Indexes/test.txt')

    train_ind = [i for i in range(len(df1)) if i not in valid_ind+test_ind]

    random.shuffle(train_ind)
    random.shuffle(valid_ind)
    random.shuffle(test_ind)

    print('Total training samples :', len(train_ind))
    print('Total validation samples :', len(valid_ind))
    print('Total testing samples :', len(test_ind))

    for i in test_ind:
        if i in train_ind:
            print('Data Leakage !!!')

    centralized_model = IamEncoder(input_size, lstm_hidden_size, num_layers, att_size).to(device)
    
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = optim.Adam(centralized_model.parameters(), lr = lr)

    print('Training ...')

    best_loss = 100

    for e in range(epochs):

        train_loss = 0
        k1 = 0
        centralized_model.train()

        for i in range(0, len(train_ind), batch_size):

            batch_indexes = train_ind[i:i+batch_size]
            optimizer.zero_grad()

            x1 = reviews[batch_indexes].to(device)
            x2 = titles[batch_indexes].to(device)
            x3 = get_me_the_images(batch_indexes).to(device)

            p1, p2, p3 = centralized_model(x1, x2, x3)

            y1 = torch.tensor(df1.iloc[batch_indexes]['Emotion'].tolist()).to(device)
            y2 = torch.tensor(df1.iloc[batch_indexes]['Sentiment'].tolist()).to(device)
            y3 = torch.tensor(df1.iloc[batch_indexes]['Complaint'].tolist()).to(device)

            l1 = criterion(p1, y1)
            l2 = criterion(p2, y2)
            l3 = criterion(p3, y3)

            w = 3
            loss = w * l3
            if shall_i_emot:
                loss += l1
                w += 1
            if shall_i_sent:
                loss += l2
                w += 1

            loss = loss / w
        
            loss.backward()
            optimizer.step()

            train_loss += loss
            k1 += 1

            # del x1, x2, x3, p1, p2, p3, y1, y2, y3, l1, l2, l3

        with torch.no_grad():
                
            valid_loss = 0
            k2 = 0
            centralized_model.eval()
            for i in range(0, len(valid_ind), batch_size):

                batch_indexes = valid_ind[i:i+batch_size]
                x1 = reviews[batch_indexes]
                x2 = titles[batch_indexes]
                x3 = get_me_the_images(batch_indexes)


                p1, p2, p3 = centralized_model(x1.to(device), x2.to(device), x3.to(device))

                y3 = torch.tensor(df1.iloc[batch_indexes]['Complaint'].tolist()).to(device)
                l3 = criterion(p3, y3)

                valid_loss += l3
                k2 += 1

                # del x1, x2, x3, p1, p2, p3, y3, l3, batch_indexes
        
        print()
        print('Epoch :', e, '; Total Training Loss :', train_loss.item() / k1, '; Complaint Validation Loss :', valid_loss.item() / k2)


        if valid_loss < best_loss:
            best_loss = valid_loss
            PATH = 'path/Code/I5/BM.pth'
            print('Saving the model ...')
            torch.save(centralized_model, PATH)  

    del centralized_model

    with torch.no_grad():


        test_model = IamEncoder(input_size, lstm_hidden_size, num_layers, att_size).to(device)

        print('Loading best model to test ...')
        PATH = 'path/Code/I5/BM.pth'
        test_model = torch.load(PATH, map_location = device)
        test_model.eval()

        pred1, pred2, pred3 = [], [], []
        
        gnd1 = torch.tensor(df1.iloc[test_ind]['Emotion'].tolist(), dtype=torch.float32)
        gnd2 = torch.tensor(df1.iloc[test_ind]['Sentiment'].tolist(), dtype=torch.float32)
        gnd3 = torch.tensor(df1.iloc[test_ind]['Complaint'].tolist(), dtype=torch.float32)
        
        test_model.eval()
        
        for i in range(0, len(test_ind), batch_size):

            batch_indexes = test_ind[i:i+batch_size]

            x1 = reviews[batch_indexes].to(device)
            x2 = titles[batch_indexes].to(device)
            x3 = get_me_the_images(batch_indexes).to(device)
            
            p1, p2, p3 = test_model(x1, x2, x3)

            p1 = torch.argmax(p1, 1)
            p2 = torch.argmax(p2, 1)
            p3 = torch.argmax(p3, 1)
            
            pred1.append(p1.cpu().detach().numpy())
            pred2.append(p2.cpu().detach().numpy())
            pred3.append(p3.cpu().detach().numpy())

        gnd1 = list(deepflatten(gnd1))
        gnd2 = list(deepflatten(gnd2))
        gnd3 = list(deepflatten(gnd3))

        pred1 = list(deepflatten(pred1))
        pred2 = list(deepflatten(pred2))
        pred3 = list(deepflatten(pred3))

        rep1 = classification_report(gnd1, pred1, digits = 4)
        rep2 = classification_report(gnd2, pred2, digits = 4)
        rep3 = classification_report(gnd3, pred3, digits = 4)

        print(rep3)

        with open(file_name, "a") as f:
            f.write('Emotion \n')
            f.write(rep1 + '\n \n')
            f.write('Sentiment \n')
            f.write(rep2 + '\n \n')
            f.write('Complaint \n')
            f.write(rep3 + '\n \n \n')

        
        del test_model, rep1, rep2, rep3
        del gnd1, pred1, gnd2, pred2, gnd3, pred3


else:
    print(file_name, 'not found!')