"""
Name: ClientSampling.py
Date: Nov 2021
To sample clients based on their probability and return their corresponding training samples' indexes
"""

# Import necessary inbuilt libraries
import random
import json
from iteration_utilities import deepflatten
import pandas as pd

with open("config.json") as json_data_file:
    data = json.load(json_data_file)
print('Loading the config.json file ...')
no_support = data["no_support"]
no_query = data["no_query"]


def active_clients(df1, df2, cpr):
    """
    Sample clients based on their train-points count or their probability
    :param df1: Complete dataframe
    :param df2: Dataframe with client/product name, their #occurances
    :param cpr: Clients Per Round

    :return : list of client's training samples' indexes, List of participating clients' names
    """

    global no_support, no_query

    participating_clients = random.choices(df2['Client'], weights = df2['Count'], k = cpr)

    client_support_index = []
    client_query_index = []

    for client in participating_clients:

        client_df = df1.loc[df1['Product'] == client]

        emotions = client_df.Emotion.unique().tolist()
        sentiments = client_df.Sentiment.unique().tolist()
        complaints = client_df.Complaint.unique().tolist()

        emotions.sort()
        sentiments.sort()
        complaints.sort()
        
        if len(emotions) + len(sentiments) + len(complaints) != 8:
            return None, None, None 

        tasks = [emotions, sentiments, complaints]
        column = ['Emotion', 'Sentiment', 'Complaint']

        task_support_index = []
        task_query_index = []

        for task, name in zip(tasks, column):
            categ_support_index = []
            categ_query_index = []

            for categ in task:
                sub_df = client_df.loc[client_df[name] == categ]

                indexes = sub_df.index.tolist()
                random.shuffle(indexes)

                if len(indexes) >= 2 * no_support:
                    support_index = indexes[:no_support]
                    query_index = indexes[no_support : no_query + no_support]
                
                else:
                    l = int(len(indexes)/2)
                    if l < 2:
                        return None, None, None

                    else:
                        support_index = indexes[:l]
                        query_index = indexes[l:]
                
                categ_support_index.append(support_index)
                categ_query_index.append(query_index)
            
            task_support_index.append(categ_support_index)
            task_query_index.append(categ_query_index)

        client_support_index.append(task_support_index)
        client_query_index.append(task_query_index)

    if cpr == 1:
        client_support_index = [client_support_index]
        client_query_index = [client_query_index]
        participating_clients = [participating_clients]

    return client_support_index, client_query_index, participating_clients



def dormant_clients(df1, df2, no_support = 10):
    """
    Sample dormant clients for validating and testing
    :param df1: Complete dataframe
    :param df2: Dataframe with client/product name, their #occurances
    :param no_support: #Support instances
    """

    df3_frames = []

    dormant_products = df2['Client'].tolist()
    # dormant_products.sort()

    for d_client in dormant_products:
        df3_frames.append(df1.loc[df1['Product'] == d_client])
    
    df3 = pd.concat(df3_frames)
    d_clients = df3.Domain.value_counts().index.tolist()
    print(d_clients)
    # d_clients.sort()

    client_support_index = []
    final_test_index = []

    for client in d_clients:

        client_df = df3.loc[df3['Domain'] == client]

        test_index = client_df.index.tolist()
        emotions = client_df.Emotion.unique().tolist()
        sentiments = client_df.Sentiment.unique().tolist()
        complaints = client_df.Complaint.unique().tolist()

        emotions.sort()
        sentiments.sort()
        complaints.sort()

        
        if len(emotions) + len(sentiments) + len(complaints) != 8:
            print(client, emotions, sentiments, complaints)
            return None, None, None 

        tasks = [emotions, sentiments, complaints]
        column = ['Emotion', 'Sentiment', 'Complaint']

        task_support_index = []

        for task, name in zip(tasks, column):
            categ_support_index = []

            for categ in task:
                sub_df = client_df.loc[client_df[name] == categ]

                indexes = sub_df.index.tolist()

                if len(indexes) >= 2 * no_support:
                    support_index = indexes[:no_support]
                
                else:
                    l = int(len(indexes)/2)
                    if l < 2:
                        return None, None, None

                    else:
                        support_index = indexes[:l]
                
                categ_support_index.append(support_index)
            
            task_support_index.append(categ_support_index)

        client_support_index.append(task_support_index)

        s = list(set(deepflatten(client_support_index)))
        t = list(set(deepflatten(test_index)))

        d_client_test_index = [i for i in t if i not in s]
        final_test_index.append(d_client_test_index)

    return client_support_index, final_test_index, d_clients