"""
Name: PreProcess.py
Date: Nov 2021
To spre-process the raw dataset
"""

import pandas as pd

path1 = 'path/Combined_Dataset/P1.csv'
path2 = 'path/Combined_Dataset/P2.csv'

df1 = pd.read_csv(path1)
df2 = pd.read_csv(path2)

df3 = pd.concat([df1, df2])
df3 = df3.reset_index(drop=True)

df3['Product'] = [url.split('/')[3] for url in df3['PageURL']]
df3['Index'] = [i for i in range(len(df3))]

# To handle NaN values
df3['Review'] = df3['Review'].fillna(df3['Title'])
df3.fillna(0, inplace=True)

# Map categorical variable to numerical
emotion_dict = {'anger' : 0, 'fear' : 0, 'sadness' : 1, 'disgust' : 1, 'happiness' : 2}
df3.Emotion = df3.Emotion.map(emotion_dict)

print('Emotion unique:', df3.Emotion.unique())
print('Domain unique:', df3.Domain.unique())


Emot = ['anger/fear', 'sadness/disgust', 'happiness']
for e in df3.Emotion.unique().tolist():
    print(Emot[e])
    print(df3.loc[df3.Emotion == e].Complaint.value_counts())

for d in df3.Domain.unique().tolist():
    print(d)
    print(df3.loc[df3.Domain == d].Complaint.value_counts())


df3.to_csv('path/Combined_Dataset/Combined.csv')
