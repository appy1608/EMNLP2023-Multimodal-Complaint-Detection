"""
Name: Central.py
Date: November 2021
ProtoFed-MCI model
"""

# Import necessary inbuilt libraries
import pandas as pd
import torch
import torch.nn as nn
from torch import optim
import torch.nn.functional as F
from torch.autograd import Function
import torchvision.models as models
import torchvision.transforms as T
from PIL import Image
import warnings
import json

warnings.filterwarnings("ignore")
device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

with torch.no_grad():
    torch.cuda.empty_cache()
    
# Load hyper-parameters from config.json file
with open("config.json") as json_data_file:
    data = json.load(json_data_file)

is_it_bidirectional = data["is_it_bidirectional"]
final_dense = data["final_dense"]
multi_modal = data["multi_modal"]
shall_i_have_contextual = data["shall_i_have_contextual"]
shall_i_have_inter_segment = data["shall_i_have_inter_segment"]

encoder_shape = 768

# Download and freeze ResNet model
resnet18 = models.resnet18(pretrained=True)
resnet18 = torch.nn.Sequential(*(list(resnet18.children())[:-3])).to(device)

for param in resnet18.parameters():
    param.requires_grad = False
    
class self_attention(nn.Module):
    """
    Self Attention between each of RNN's output and final output
    """
    def __init__(self, size_in, size_out, fact):
        super().__init__()

        inter_med = int(size_in/fact)
        self.attn = nn.Linear(size_in, inter_med)
        self.concat_linear = nn.Linear(2*inter_med, size_out)

    def forward(self, encoder_states, final_hidden_state):
        final_state = self.attn(final_hidden_state)
        attn_weights = torch.bmm(encoder_states, final_state.unsqueeze(2))
        attn_weights = F.softmax(attn_weights.squeeze(2), dim=1)
        context = torch.bmm(encoder_states.transpose(1, 2), attn_weights.unsqueeze(2)).squeeze(2)
        attn_hidden = F.relu(self.concat_linear(torch.cat((context, final_state), dim=1)))
        return attn_hidden

class Ie_attention(nn.Module):
    """
    Inter-segment Inter-modal Attention
    Sentiment and Emotion help Sarcasm? A Multi-task Learning Framework for Multi-Modal Sarcasm, Sentiment and Emotion Analysis
    https://aclanthology.org/2020.acl-main.401.pdf
    """   
    def __init__(self):
        super().__init__()
    
    def Ie_attention_score(self, T1, T2):
        M = torch.bmm(T2, T2.transpose(1, 2))
        P = F.softmax(M, dim = 1)
        O = torch.matmul(P, T2)
        return_me = torch.mul(O, T1) # Element-wise multiplication
        return return_me

    def forward(self, vec1, vec2, units_per_token = 4):
        T1 = []
        T2 = []
        for token_index in range(0, int(vec1.shape[-1]/units_per_token)):
            T1.append(vec1[:, token_index*units_per_token:(token_index+1)*units_per_token])
            T2.append(vec2[:, token_index*units_per_token:(token_index+1)*units_per_token])
        T1 = torch.stack(T1, dim = 1)
        T2 = torch.stack(T2, dim = 1)
        attentioned = self.Ie_attention_score(T1, T2)
        return attentioned.flatten(1) 


class Ac_attention(nn.Module):
    """
    Multi-modal Multi-utterance - Bi-modal Attention
    Contextual Inter-modal Attention for Multi-modal Sentiment Analysis
    https://aclanthology.org/D18-1382.pdf
    """  
    def __init__(self):
        super().__init__()    

    def forward(self, V, T,):
        M1 = torch.matmul(V, T.T)
        M2 = torch.matmul(T, V.T)
        N1 = F.softmax(M1, dim = 1)
        N2 = F.softmax(M2, dim = 1)
        O1 = torch.matmul(N1, T)
        O2 = torch.matmul(N2, V)
        A1 = torch.mul(O1, V)
        A2 = torch.mul(O2, T)
        A_final = torch.cat((A1, A2), dim = 1)
        return A_final
        

class IamEncoder(nn.Module):
    """
    Main classifier
    """  
    def __init__(self, input_size, hidden_size, num_layers, att_size):
        super(IamEncoder, self).__init__()

        global Ie_attention, Ac_attention
        global is_it_bidirectional, final_dense, multi_modal, shall_i_have_contextual, shall_i_have_contextual, projection_shape

        self.final_dense = final_dense
        self.multi_modal = multi_modal
        self.shall_i_have_inter_segment = shall_i_have_inter_segment
        self.contextual = shall_i_have_contextual
        self.shall_i_have_contextual = shall_i_have_contextual

        self.is_it_bidirectional_numerical = is_it_bidirectional * 1
        l = num_layers * (self.is_it_bidirectional_numerical + 1)
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.resnet_final_size = 256
        self.att_size = att_size
        self.encoder_shape = encoder_shape
        
        self.comp_targ_size = 2
        self.emot_targ_size = 3
        self.sent_tag_size = 3

        self.multi_model_size = 128

        if self.shall_i_have_inter_segment and self.shall_i_have_contextual:
            self.mega_cat_size = 7 * self.multi_model_size

        elif self.shall_i_have_inter_segment and  (not self.shall_i_have_contextual):
            self.mega_cat_size = 3 * self.multi_model_size

        elif (not self.shall_i_have_inter_segment) and self.shall_i_have_contextual:
            self.mega_cat_size = 3 * self.multi_model_size

        elif not(self.shall_i_have_inter_segment and self.shall_i_have_contextual):
            self.mega_cat_size = 3 * self.multi_model_size

        # Linear layer - Pre-shared LSTM
        self.linear_preshare_R = nn.Linear(input_size, self.resnet_final_size)
        self.linear_preshare_T = nn.Linear(input_size, self.resnet_final_size)

        # Shared RNN - 4 modalities
        self.rnn_S = nn.LSTM(self.resnet_final_size, hidden_size, num_layers, bidirectional = is_it_bidirectional, batch_first = True)

        # RNN for Review embeddings
        self.rnn_R = nn.LSTM(input_size, hidden_size, num_layers, bidirectional = is_it_bidirectional, batch_first=True)

        # RNN for Title embeddings
        self.rnn_T = nn.LSTM(input_size, hidden_size, num_layers, bidirectional = is_it_bidirectional, batch_first=True)

        # RNN for Images' ResNet embedding
        self.rnn_I = nn.LSTM(self.resnet_final_size, hidden_size, num_layers, bidirectional = is_it_bidirectional, batch_first=True)

        # Self Attention - Shared
        self.SelfAtten_comp_S = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)        

        # Self Attention - Review - Task specific
        self.SelfAtten_comp_R = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)
        self.SelfAtten_emot_R = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)
        self.SelfAtten_sent_R = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)

        # Self Attention - Title - Task specific
        self.SelfAtten_comp_T = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)
        self.SelfAtten_emot_T = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)
        self.SelfAtten_sent_T = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)


        # Self Attention for image embedding
        self.SelfAtten_img = self_attention(l*hidden_size, self.att_size, self.is_it_bidirectional_numerical + 1)

        # Linear layer - Shared
        self.linear_shared = nn.Linear(att_size, self.multi_model_size)

        # Projection layer - Combined (Review + Title) - Task specific
        self.linear_comp_C = nn.Linear(2*att_size, self.encoder_shape)
        self.linear_emot_C = nn.Linear(2*att_size, self.encoder_shape)
        self.linear_sent_C = nn.Linear(2*att_size, self.encoder_shape)

        # Linear layer - Image
        self.linear_img = nn.Linear(self.att_size, self.multi_model_size)

        # Linear Layer - Combined (Review + Title) - pre-InterModal Attn 
        self.linear_comp2_C = nn.Linear(self.encoder_shape, self.multi_model_size)

        # Inter-segment Inter-modal Attention Layer
        self.IeAtten = Ie_attention()

        # Contextual Inter-modal Attention Layer
        self.AcAtten = Ac_attention()

        # Mega Linear Layers
        self.linear1_mega = nn.Linear(self.mega_cat_size, 512)
        self.linear2_mega = nn.Linear(512, self.encoder_shape)

        # Projection Layer - Final Complaint 
        self.final_linear_comp = nn.Linear(2*self.encoder_shape, self.encoder_shape)

    def forward(self, r, t, img):

        # global resnet18
        R = torch.nn.ReLU()
        D = torch.nn.Dropout(0.2)
        N = r.shape[0]

        r = r.to(device)
        t = t.to(device)
        img = img.to(device)

        resnet_feat = resnet18(img)
        resnet_glob_avg_pool = resnet_feat.mean(dim=(-2, -1)).unsqueeze(-1).view(N, 1, self.resnet_final_size)

        R_shared = D(R(self.linear_preshare_R(r)))
        T_shared = D(R(self.linear_preshare_T(t)))

        Concat_shared = torch.cat((R_shared, T_shared, resnet_glob_avg_pool), dim = 1)
        # Concat_shared : (N, cat_seq_len, resnet_final_size)
        S_encoder, (hidden, cell) = self.rnn_S(Concat_shared)
        # hidden = hidden.view(hidden.shape[1], hidden.shape[0]* hidden.shape[-1])
        hidden = R(hidden.permute(1, 0, 2).flatten(-2))
        S_attn_comp = self.SelfAtten_comp_S(S_encoder, hidden)

        shared1 = D(R(self.linear_shared(S_attn_comp)))

        # r : (N, seq_length, embedding_size)
        R_encoder, (hidden, cell) = self.rnn_R(r)
        # hidden = hidden.view(hidden.shape[1], hidden.shape[0]* hidden.shape[-1])
        hidden = R(hidden.permute(1, 0, 2).flatten(-2))
        R_atten_comp = self.SelfAtten_comp_R(R_encoder, hidden)
        R_atten_emot = self.SelfAtten_emot_R(R_encoder, hidden)
        R_atten_sent = self.SelfAtten_sent_R(R_encoder, hidden)

        # t : (N, seq_length, embedding_size)
        T_encoder, (hidden, cell) = self.rnn_T(t)
        # hidden = hidden.view(hidden.shape[1], hidden.shape[0]* hidden.shape[-1])
        hidden = R(hidden.permute(1, 0, 2).flatten(-2))
        T_atten_comp = self.SelfAtten_comp_T(T_encoder, hidden)
        T_atten_emot = self.SelfAtten_emot_T(T_encoder, hidden)
        T_atten_sent = self.SelfAtten_sent_T(T_encoder, hidden)

        # resnet_glob_avg_pool : (N, 1, embedding_size)
        I_encoder, (hidden, cell) = self.rnn_I(resnet_glob_avg_pool)
        # hidden = hidden.view(hidden.shape[1], hidden.shape[0]* hidden.shape[-1])
        hidden = R(hidden.permute(1, 0, 2).flatten(-2))
        atten_img = self.SelfAtten_img(I_encoder, hidden)
        img1 = D(R(self.linear_img(atten_img)))

        C_atten_comp = torch.cat((R_atten_comp, T_atten_comp), dim = -1)
        C_atten_emot = torch.cat((R_atten_emot, T_atten_emot), dim = -1)
        C_atten_sent = torch.cat((R_atten_sent, T_atten_sent), dim = -1)

        comp1 = D(self.linear_comp_C(C_atten_comp))
        emot1 = D(self.linear_emot_C(C_atten_emot))
        sent1 = D(self.linear_sent_C(C_atten_sent))

        if self.multi_modal:
            # ReLU this
            comb1 = D(R(self.linear_comp2_C(comp1)))

            As_CI = self.IeAtten(comb1, img1)
            As_IC = self.IeAtten(img1, comb1)
            
            Ac_IC = self.AcAtten(img1, comb1)

            if self.shall_i_have_inter_segment and self.shall_i_have_contextual:
                # print('Using both form of inter-modal attention')
                mega_concat = R(torch.cat((As_CI, As_IC, Ac_IC, comb1, img1, shared1), dim = -1))

            elif self.shall_i_have_inter_segment and  (not self.shall_i_have_contextual):
                # print('Using only inter-segment inter-modal attention')
                mega_concat = R(torch.cat((As_CI, As_IC, comb1, img1, shared1), dim = -1))

            elif (not self.shall_i_have_inter_segment) and self.shall_i_have_contextual:
                # print('Using only contextual inter-modal attention')
                mega_concat = R(torch.cat((Ac_IC, comb1, img1, shared1), dim = -1))

            elif not(self.shall_i_have_inter_segment and self.shall_i_have_contextual):
                # print('Not using any inter-modal attention')
                mega_concat = R(torch.cat((comb1, img1, shared1), dim = -1))

            multi_modal_final = D(R(self.linear2_mega(D(R((self.linear1_mega(mega_concat)))))))
            
            comp1 = torch.cat((multi_modal_final, comp1),dim = -1)
            comp1 = D(self.final_linear_comp(comp1))

        return comp1