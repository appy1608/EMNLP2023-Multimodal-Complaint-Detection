"""
Name: Accuracy.py
Date: Nov 2021
To calculate accuracy
"""

# Import necessary inbuilt libraries
import torch
import numpy as np

def get_me_the_accuracy(pred, targ):
    """
    To calculate accuracy
    :param pred: predicted index
    :param targ: Target values - Ground truth values
    :return : accuracy
    """
    # pred_argmax = torch.argmax(pred, 1)
    acc = torch.eq(pred.to("cpu"), targ.to("cpu")).float().mean()
    return np.round(acc.item(), 3)