"""
Name: Embed.py
Date: Nov 2021
To embed the reviews and titles using BERT following https://mccormickml.com/2019/05/14/BERT-word-embeddings-tutorial/
and emojis based on https://github.com/uclnlp/emoji2vec
"""

# Import necessary inbuilt libraries
from transformers import BertTokenizer, BertModel
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
import pandas as pd
import emoji
import numpy as np
import torch
import gensim.models as gsm
import warnings

warnings.filterwarnings("ignore")

# Downloaded the emoji2vec.bin from https://github.com/uclnlp/emoji2vec/tree/master/pre-trained
e2v = gsm.KeyedVectors.load_word2vec_format('path/emoji2vec.bin', binary=True)

# Maximum tokens per sentence (for BERT embedding)
max_len = 512

# Load the main DataFrame
df_path = 'path/Combined_Dataset/Combined.csv'
df1 = pd.read_csv(df_path)

df1['Index'] = [i for i in range(len(df1))]
df1.head(5)

df1['Review'] = df1['Review'].fillna(df1['Title'])
print('NaN counts:\n', df1.isna().sum())


# def clean_the_sentence(s1, s2):
#     """
#     Extract emojies from reviews and titles
#     :param s1: sentence 1 - the reivew
#     :param s2: sentence 2 - the title
#     :return : list of unique emojies, cleaned review, cleaned title
#     """
#     extracted_emoji = []
#     r = ''
#     t = ''
#     for l in s1:
#         if l in emoji.UNICODE_EMOJI['en']:
#             extracted_emoji.append(l)
#         else:
#             r = r + l
#     for l in s2:
#         if l in emoji.UNICODE_EMOJI['en']:
#             extracted_emoji.append(l)
#         else:
#             t = t + l
#     extracted_emoji = set(extracted_emoji)
#     return extracted_emoji, r, t


# emojies = []
# # reviews = []
# # titles = []

# for r, t in zip(df1.Review, df1.Title):
#     e, r, t = clean_the_sentence(r, t)
#     emojies.append(e)
#     # reviews.append(r)
#     # titles.append(t)

# maxi = 0
# sum = 0
# count = 0

# for e in emojies:
#     if len(e) > 0:
#         sum += len(e)
#         count += 1
#     if len(e) > maxi:
#         maxi = len(e)

# print('Maximum emojies per review :', maxi)
# print('Average emoji per review(E):', np.round(sum/count, 3)) # Ratio btw #emojies and #entries that contain emojies
# print('Average emoji per review(I):', np.round(sum/len(df1), 3)) # Ratio btw #emojies and total #entries

# # Embedd extracted emojies and pad it to a length of 10
# embedded_emojies = []

# for emoj in emojies:
#     emb = []
#     for e in emoj:
#         try:
#             emb.append(e2v[e])
#         except:
#             pass
#     for i in range(10 - len(emb)):
#         # Each emoji embedded to (1, 300) vector
#         emb.append(np.zeros(300))
#     embedded_emojies.append(np.stack(emb))

# # Save embedded emojies
# embedded_emojies = torch.tensor(embedded_emojies)
# torch.save(embedded_emojies, 'path/Embedded/EmojiEmbedded.pt')
# print('Emojies embedded and saved. Final shape:', embedded_emojies.shape)

# # Load BERT
# model = BertModel.from_pretrained('bert-base-uncased', output_hidden_states = True)
# model.eval()

# def BERT_embed(text, model = model):
#     """
#     Embed each sentence to a vector of shape (max_len, 768) by averaging the last 4 layer's hidden vectors
#     :param text: text to be embedded
#     :param model: BERT model
#     :return : embedded sentence
#     """
#     cls_text_sep = "[CLS] " + text + " [SEP]"
#     tokenized_text = tokenizer.tokenize(cls_text_sep)

#     if len(tokenized_text) > 510:
#         tokenized_text = tokenized_text[:511] + ["[SEP]"]
#     indexed_tokens = tokenizer.convert_tokens_to_ids(tokenized_text)
#     segments_ids = [1] * len(tokenized_text)
#     tokens_tensor = torch.tensor([indexed_tokens])
#     segments_tensors = torch.tensor([segments_ids])

#     with torch.no_grad():
#         outputs = model(tokens_tensor, segments_tensors)
#         hidden_states = outputs[2]

#     token_embeddings = torch.stack(hidden_states, dim=0).squeeze(1).permute(1,0,2)

#     token_vecs_sum = []

#     for token in token_embeddings:
#         sum_vec = torch.sum(token[-4:], dim=0) / 4  
#         token_vecs_sum.append(sum_vec)

#     token_vecs_sum = torch.stack(token_vecs_sum)

#     if len(token_vecs_sum) < max_len:
#         token_vecs_sum = torch.cat((token_vecs_sum, torch.zeros((max_len - token_vecs_sum.shape[0], token_vecs_sum.shape[1]))))
#     else:
#         token_vecs_sum = token_vecs_sum[:max_len]

#     return token_vecs_sum

# # Embed and save the titles
# embedded = []
# for i, title in enumerate(df1.Title):
#     emb = BERT_embed(title)
#     embedded.append(emb)
#     if (i+1) % 1000 == 0:
#         print(i+1, 'Titles embedded.', len(df1) - i - 1, 'left.')
# embedded = torch.stack(embedded)
# torch.save(embedded, 'path/Embedded/TitleEmbedded.pt')
# print('Titles embedded and saved. Final shape:', embedded.shape)

# # Embed and save the reivews
# embedded = []
# for i, rev in enumerate(df1.Review):
#     emb = BERT_embed(rev)
#     embedded.append(emb)
#     if (i+1) % 1000 == 0:
#         print(i+1, 'Reviews embedded.', len(df1) - i - 1, 'left.')
# embedded = torch.stack(embedded)
# torch.save(embedded, 'path/Embedded/ReviewEmbedded.pt')
# print('Reviews embedded and saved. Final shape:', embedded.shape)




# Load BERT
model = BertModel.from_pretrained('bert-base-uncased', output_hidden_states = True)
model.eval()

def BERT_embed(text, model = model):
    """
    Embed each sentence to a vector of shape (max_len, 768) by averaging the last 4 layer's hidden vectors
    :param text: text to be embedded
    :param model: BERT model
    :return : embedded sentence
    """
    cls_text_sep = "[CLS] " + text + " [SEP]"
    tokenized_text = tokenizer.tokenize(cls_text_sep)

    if len(tokenized_text) > 510:
        tokenized_text = tokenized_text[:511] + ["[SEP]"]
    indexed_tokens = tokenizer.convert_tokens_to_ids(tokenized_text)
    segments_ids = [1] * len(tokenized_text)
    tokens_tensor = torch.tensor([indexed_tokens])
    segments_tensors = torch.tensor([segments_ids])

    with torch.no_grad():
        outputs = model(tokens_tensor, segments_tensors)
        hidden_states = outputs[2]

    token_embeddings = torch.stack(hidden_states, dim=0).squeeze(1).permute(1,0,2)

    token_vecs_sum = []

    for token in token_embeddings:
        sum_vec = torch.sum(token[-4:], dim=0) / 4  
        token_vecs_sum.append(sum_vec)

    token_vecs_sum = torch.stack(token_vecs_sum)

    if len(token_vecs_sum) < max_len:
        token_vecs_sum = torch.cat((token_vecs_sum, torch.zeros((max_len - token_vecs_sum.shape[0], token_vecs_sum.shape[1]))))
    else:
        token_vecs_sum = token_vecs_sum[:max_len]

    return token_vecs_sum

# Embed and save the titles
embedded = []
for i, title in enumerate(df1.Title):
    title = emoji.demojize(title)
    emb = BERT_embed(title)
    embedded.append(emb)
    if (i+1) % 1000 == 0:
        print(i+1, 'Titles embedded.', len(df1) - i - 1, 'left.')
embedded = torch.stack(embedded)
torch.save(embedded, 'path/Embedded/TitleEmbedded2.pt')
print('Titles embedded and saved. Final shape:', embedded.shape)

# Embed and save the reivews
embedded = []
for i, rev in enumerate(df1.Review):
    rev = emoji.demojize(rev)
    emb = BERT_embed(rev)
    embedded.append(emb)
    if (i+1) % 1000 == 0:
        print(i+1, 'Reviews embedded.', len(df1) - i - 1, 'left.')
embedded = torch.stack(embedded)
torch.save(embedded, 'path/Embedded/ReviewEmbeddedV2.pt')
print('Reviews embedded and saved. Final shape:', embedded.shape)

