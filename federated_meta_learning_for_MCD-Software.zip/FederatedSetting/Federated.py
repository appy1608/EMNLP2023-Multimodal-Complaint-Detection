"""
Name: Federated.py
Date: Nov 2021
To implement Federated Average
"""

# Import necessary inbuilt libraries
import pandas as pd
import torch
from torch import optim
import torchvision.transforms as T
from PIL import Image
import warnings
import numpy as np
import json
import os.path
from sklearn.metrics import classification_report
from iteration_utilities import deepflatten


# Import user-defined libraries
from ClientSampling import active_clients
from ClientSampling import dormant_clients
from ProtoNet import Proto_jector
from Accuracy import get_me_the_accuracy

warnings.filterwarnings("ignore")
device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
print('Utilizing', device, '...')

# Load hyper-parameters from config.json file
with open("config.json") as json_data_file:
    data = json.load(json_data_file)
print('Loading the config.json file ...')
epochs = data[ "epochs"]
# lr = data[ "lr"]
shall_i_multi_task = data["shall_i_multi_task"]
comm_rounds = data["comm_rounds"]
file_name = data["file_name"]
# cpr = data["cpr"]

if os.path.isfile(file_name):

    for lr in [1e-2]:
        for cpr in [15]:

            torch.cuda.empty_cache()
            print('Learning Rate:', lr)
            print('Cleints per Round:', cpr)
                    
            with open(file_name, 'a') as f: 
                f.write('\n')
                f.write('-' * 20)
                # f.write('\n')
                # for key, value in data.items(): 
                #     f.write('%s:%s\n' % (key, value))
                f.write('\n')
                f.write('Updated learning rate : ' + str(lr))
                f.write('\n')
                f.write('Updated Cleints per Round : ' + str(cpr))
                f.write('\n')
                    

            # Load the main DataFrame
            df1 = pd.read_csv('path/Combined_Dataset/Combined.csv')

            # Create clients based on unique products 
            client = df1.Product.value_counts().index.tolist()
            data_count = df1.Product.value_counts().tolist()

            # New dataframe -> Product (client) name, #Occurances, Probability (#Occurances/Total)
            df2 = pd.DataFrame({'Client':client})
            df2['Count'] = data_count
            df2['Prob'] = [d/len(df1) for d in data_count]

            split_index = np.argmax(df2['Count'] < 80 * 1)

            # print(split_index, 'products to train on ...')

            # Validate on last 10 clients (NIID case)
            df3 = df2.iloc[split_index:]
            df2 = df2.iloc[:split_index]

            # Load the embedded files
            print('Loading Embedded Vectors ...')
            reviews = torch.load('path/Embedded/ReviewEmbeddedV2.pt')
            titles = torch.load('path/Embedded/TitleEmbedded2.pt')

            def get_me_orderly(the_dash, with_these):
                me = []
                for task_ind in with_these:
                    tasks = []
                    for class_ind in task_ind:
                        classes = []
                        for samp_ind in class_ind:
                            classes.append(the_dash[samp_ind])
                        tasks.append(classes)
                    me.append(tasks)
                return me


            def get_me_the_embeddings(of_this, s_ind, q_ind):
                """
                Returns the corresponding reviews and titles
                :param indexes: indexes to select input
                :return : corresponding reviews and titles
                """
                support_of_this = get_me_orderly(of_this, s_ind)
                query_of_this = get_me_orderly(of_this, q_ind)

                # print(len(support_of_this))
                # print(len(support_of_this[-1]))
                # print(len(support_of_this[-1][-1]))    
                
                return support_of_this, query_of_this

            def get_me_the_images(s_ind, q_ind):
                """
                Returns the corresponding images
                :param indexes: indexes to select input
                :return : corresponding images
                """
                support_imgs = []
                query_imgs = []
                for task_ind in s_ind:
                    tasks = []
                    for class_ind in task_ind:
                        classes = []
                        for samp_ind in class_ind:
                            try:
                                img_name = df1['ImageURL'][samp_ind].split('/')[-1]
                                img = Image.open('path/Combined_Dataset/Images/' + img_name)
                                resized_imgs = T.ToTensor()(T.Resize((224,224))(img))
                            except:
                                resized_imgs = torch.zeros((3, 224, 224))
                            classes.append(resized_imgs)
                        tasks.append(classes)
                    support_imgs.append(tasks)

                for task_ind in q_ind:
                    tasks = []
                    for class_ind in task_ind:
                        classes = []
                        for samp_ind in class_ind:
                            try:
                                img_name = df1['ImageURL'][samp_ind].split('/')[-1]
                                img = Image.open('path/Combined_Dataset/Images/' + img_name)
                                resized_imgs = T.ToTensor()(T.Resize((224,224))(img))
                            except:
                                resized_imgs = torch.zeros((3, 224, 224))
                            classes.append(resized_imgs)
                        tasks.append(classes)
                    query_imgs.append(tasks)

                return support_imgs, query_imgs

            def get_me_the_test_images(indexes):
                """
                Returns the corresponding images
                :param indexes: indexes to select input
                :return : corresponding images
                """
                imgs = []
                for i in indexes:
                    try:
                        img_name = df1['ImageURL'][i].split('/')[-1]
                        img = Image.open('path/Combined_Dataset/Images/' + img_name)
                        resized_imgs = T.ToTensor()(T.Resize((224,224))(img))
                    except:
                        resized_imgs = torch.zeros((3, 224, 224))
                    imgs.append(resized_imgs)
                imgs = torch.stack(imgs)
                return imgs


            def arrange_me(ar1, ar2, ar3):
                me = []
                for task_no in range(len(ar1)):
                    t = []
                    for class_no in range(len(ar1[task_no])):
                        c = []
                        for sample_no in range(len(ar1[task_no][class_no])):
                            s = ([ar1[task_no][class_no][sample_no], ar2[task_no][class_no][sample_no],
                            ar3[task_no][class_no][sample_no]])
                            c.append(s)
                        t.append(c)
                    me.append(t)
                return me

            def initialize_clients(count, pretrained_path = None):
                """
                Initialize count-number of clients with random/pre-trained weights
                :param count: total number of clients
                :param pretrained_path: path to pre-trained model (default: None)
                :return : list of client models
                """
                if pretrained_path is None:
                    return [Proto_jector(no_of_tasks = 3).to(device) for i in range(count)]
                else:
                    return [Proto_jector(no_of_tasks = 3).to(device).load_state_dict(torch.load(pretrained_path)) for i in range(count)]

            
            print('Generating validation and test set ...')


            dormant_valid_support = None
            while dormant_valid_support is None:
                dormant_valid_support, dormant_valid_indexes, dormant_valid_names = dormant_clients(df1, df3)

            dormant_test_support = dormant_valid_support[1:]
            dormant_test_indexes = dormant_valid_indexes[1:]
            dormant_test_names   = dormant_valid_names[1:]
            
            dormant_valid_support = [dormant_valid_support[0]]
            dormant_valid_indexes = [dormant_valid_indexes[0]]
            dormant_valid_names   = [dormant_valid_names[0]]

            # Initialize the global/server model
            global_model = initialize_clients(1)[0]

            # Intialize a dummy all-zero model
            print('Server/Global Model initialized ...')
            zero_client = initialize_clients(1)[0]
            for p in zero_client.parameters():
                p.data = p.data * 0

            print('Contacting clients ...')

            best_val_acc = 0

            for c in range(comm_rounds):

                client_points = []

                # Sample clients based on their probability
                participating_client_support = None
                while participating_client_support is None:
                    participating_client_support, participating_client_query, participating_clients_name = active_clients(df1, df2, cpr)

                all_client_models = []
                client_protos = []

                # with open(file_name, "a") as f:
                #     f.write('Communication Round ' + str(c + 1) + '\n')

                print('Communication Round', c + 1)
                
                global_model.train()

                # Client-Side operation
                for client_ind, (support_points, query_points) in enumerate(zip(participating_client_support, participating_client_query)):

                    client_model = initialize_clients(1)[0]

                    client_model.train()

                    # Initialize each client with the server model's weights
                    client_model.load_state_dict(global_model.state_dict())

                    # print('Client ID:', client_ind)

                    # criterion = torch.nn.CrossEntropyLoss()
                    optimizer = optim.Adam(client_model.parameters(), lr = lr)

                    train_x1_support, train_x1_query = get_me_the_embeddings(reviews, support_points, query_points)
                    train_x2_support, train_x2_query = get_me_the_embeddings(titles, support_points, query_points)
                    train_x3_support, train_x3_query = get_me_the_images(support_points, query_points)

                    train_support = arrange_me(train_x1_support, train_x2_support, train_x3_support)
                    train_query = arrange_me(train_x1_query, train_x2_query, train_x3_query)

                    datapoints_count = len(train_query[0][0]) + len(train_query[1][0]) + len(train_query[2][0])
                    client_points.append(datapoints_count)

                    for e in range(epochs):
                        # print('Epoch:', e + 1)
                        optimizer.zero_grad()
                        
                        all_three_losses, all_three_accuracies, all_three_prototypes = client_model(train_support, train_query)
                        
                        if shall_i_multi_task:
                            loss = all_three_losses[0] + all_three_losses[1] + all_three_losses[2]
                            # print('Complaint:', all_three_losses[0].item(), 'Emotion:', all_three_losses[1].item(), 'Sentiment:', all_three_losses[2].item())
                            # print('Complaint:', all_three_accuracies[0].item(), 'Emotion:', all_three_accuracies[1].item(), 'Sentiment:', all_three_accuracies[2].item())
                        else:
                            # Look for the task number in ClientSampling.py
                            loss = all_three_losses[2] 
                            # print(e, ' Complaint:', all_three_losses[2].item(), all_three_accuracies[2].item())

                        loss.backward()
                        optimizer.step()
                        # print()

                    all_client_models.append(client_model)

                    # client_protos.append(all_three_prototypes)

                    del train_x1_support, train_x1_query, train_x2_support, train_x2_query
                    del train_x3_support, train_x3_query
                    del train_support, train_query, client_model, all_three_losses, all_three_accuracies, all_three_prototypes, loss

                # Change all parameters of global model to zero
                global_model.load_state_dict(zero_client.state_dict()) 

                # Aggregate each client's weights based on their #training-samples
                for ind in range(cpr):
                    for p1, p2 in zip(global_model.parameters(), all_client_models[ind].parameters()):
                        p1.data = p1.data + (client_points[ind] * p2.data / sum(client_points))

                del all_client_models

                # all_three_losses, all_three_accuracies, all_three_prototypes = global_model(valid_support, valid_query)

                global_model.eval()

                for valid_ind, (support_points, valid_indexes) in enumerate(zip(dormant_valid_support, dormant_valid_indexes)):

                    valid_x1_support, valid_x1_support = get_me_the_embeddings(reviews, support_points, support_points)
                    valid_x2_support, valid_x2_support = get_me_the_embeddings(titles, support_points, support_points)
                    valid_x3_support, valid_x3_support = get_me_the_images(support_points, support_points)

                    valid_support = arrange_me(valid_x1_support, valid_x2_support, valid_x3_support)

                    all_three_losses, all_three_accuracies, all_three_prototypes = global_model(valid_support, valid_support)

                    # Sample the validation data-points
                    valid_y1 = torch.tensor(df1.iloc[valid_indexes]['Emotion'].tolist(), dtype=torch.float32)
                    valid_y2 = torch.tensor(df1.iloc[valid_indexes]['Sentiment'].tolist(), dtype=torch.float32)
                    valid_y3 = torch.tensor(df1.iloc[valid_indexes]['Complaint'].tolist(), dtype=torch.float32)

                    valid_x1 = reviews[valid_indexes]
                    valid_x2 = titles[valid_indexes]
                    valid_x3 = get_me_the_test_images(valid_indexes)

                    vdumind = 0
                    acc1 = 0
                    acc2 = 0
                    acc3 = 0

                    for ind in range(0, len(valid_x1), 10):
                        bridge = 10 if ind < len(valid_x1) - 10 else len(valid_x1) - ind
                        
                        v_ind = [i for i in range(ind, ind + bridge)]
                        
                        PR3D = global_model.testing(valid_x1[v_ind], valid_x2[v_ind], valid_x3[v_ind], all_three_prototypes)
                        acc1 += get_me_the_accuracy(PR3D[0], valid_y1[v_ind])
                        acc2 += get_me_the_accuracy(PR3D[1], valid_y2[v_ind])
                        acc3 += get_me_the_accuracy(PR3D[2], valid_y3[v_ind])
                        vdumind += 1

                    print('\t', dormant_valid_names[valid_ind], '; Accuracies - Emotion : ' , round(acc1 / vdumind, 4), 'Sentiment : ', round(acc2 / vdumind, 4), 'Complaint : ',  round(acc3 / vdumind, 4))

                
                if acc3 > best_val_acc:
                    best_val_acc = acc3
                    PATH = 'path/Code/I4/BM.pth'
                    saving_at = c
                    print('Saving the model ...')
                    torch.save(global_model, PATH)

                del valid_ind, support_points, valid_indexes
                del valid_x1_support, valid_x2_support, valid_x3_support
                del valid_support
                del all_three_losses, all_three_accuracies, all_three_prototypes
                del valid_x1, valid_x2, valid_x3
                del acc1, acc2, acc3, vdumind, PR3D

            print('Loading best model to test ...')
            test_model = torch.load(PATH)
            test_model.eval()

            pred1 = []
            pred2 = []
            pred3 = []
            
            gnd1 = []
            gnd2 = []
            gnd3 = []

            for test_ind, (support_points, test_indexes) in enumerate(zip(dormant_test_support, dormant_test_indexes)):

                test_x1_support, test_x1_support = get_me_the_embeddings(reviews, support_points, support_points)
                test_x2_support, test_x2_support = get_me_the_embeddings(titles, support_points, support_points)
                test_x3_support, test_x3_support = get_me_the_images(support_points, support_points)
                test_support = arrange_me(test_x1_support, test_x2_support, test_x3_support)

                all_three_losses, all_three_accuracies, all_three_prototypes = test_model(test_support, test_support)

                # Sample the test data-points
                test_y1 = torch.tensor(df1.iloc[test_indexes]['Emotion'].tolist(), dtype=torch.float32)
                test_y2 = torch.tensor(df1.iloc[test_indexes]['Sentiment'].tolist(), dtype=torch.float32)
                test_y3 = torch.tensor(df1.iloc[test_indexes]['Complaint'].tolist(), dtype=torch.float32)
                test_x1 = reviews[test_indexes]
                test_x2 = titles[test_indexes]
                test_x3 = get_me_the_test_images(test_indexes)

                gnd1.append(test_y1.cpu().numpy())
                gnd2.append(test_y2.cpu().numpy())
                gnd3.append(test_y3.cpu().numpy())

                for ind in range(0, len(test_x1), 10):
                    bridge = 10 if ind < len(test_x1) - 10 else len(test_x1) - ind
                    v_ind = [i for i in range(ind, ind + bridge)] 
                    PR3D = test_model.testing(test_x1[v_ind], test_x2[v_ind], test_x3[v_ind], all_three_prototypes)
                    
                    pred1.append(PR3D[0].cpu().numpy())
                    pred2.append(PR3D[1].cpu().numpy())
                    pred3.append(PR3D[2].cpu().numpy())

            gnd1 = list(deepflatten(gnd1))
            gnd2 = list(deepflatten(gnd2))
            gnd3 = list(deepflatten(gnd3))

            pred1 = list(deepflatten(pred1))
            pred2 = list(deepflatten(pred2))
            pred3 = list(deepflatten(pred3))

            rep1 = classification_report(gnd1, pred1, digits = 4)
            rep2 = classification_report(gnd2, pred2, digits = 4)
            rep3 = classification_report(gnd3, pred3, digits = 4)

            with open(file_name, "a") as f:
                f.write('Model saved at ' + str(saving_at) + '\n')
                f.write('Emotion \n')
                f.write(rep1 + '\n \n')
                f.write('Sentiment \n')
                f.write(rep2 + '\n \n')
                f.write('Complaint \n')
                f.write(rep3 + '\n \n \n')

            
            del test_model, rep1, rep2, rep3
            del gnd1, pred1, gnd2, pred2, gnd3, pred3


else:
    print(file_name, 'not found!')