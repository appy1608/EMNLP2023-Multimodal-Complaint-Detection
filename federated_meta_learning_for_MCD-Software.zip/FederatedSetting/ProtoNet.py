"""
Name: ProtoNet.py
Date: Nov 2021
ProtoNet part of ProtoFed-MCI
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from Central import IamEncoder
from sklearn.manifold import TSNE

import json

device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

# Load hyper-parameters from config.json file
with open("config.json") as json_data_file:
    data = json.load(json_data_file)

lstm_hidden_size = data[ "lstm_hidden_size"]
lstm_no_layers = data[ "lstm_no_layers"]
atten_size = data[ "atten_size"]
epochs = data[ "epochs"]
shall_i_multi_task = data["shall_i_multi_task"]
comm_rounds = data["comm_rounds"]

bert_embedding_size = 768
projection_shape = 128
encoder_shape = 768

def euclidean_dist(x, y):
    n = x.shape[0]
    m = y.shape[0]
    d = x.shape[1]
    x = x.unsqueeze(1).expand(n, m, d)
    y = y.unsqueeze(0).expand(n, m, d)
    dist = torch.sqrt(torch.pow(x - y, 2).sum(-1))
    return dist
        

class Proto_jector(nn.Module):
    def __init__(self, no_of_tasks = 3):
        super(Proto_jector, self).__init__()

        global IamEncoder, projection_shape, encoder_shape
    
        self.encoder = IamEncoder(bert_embedding_size, lstm_hidden_size, lstm_no_layers, atten_size)
        self.connector = [nn.Linear(encoder_shape, projection_shape).to(device) for i in range(no_of_tasks)]
        self.projector = [nn.Linear(projection_shape, projection_shape).to(device) for i in range(no_of_tasks)]


    def forward(self, xs, xq):

        global euclidean_dist
        R = torch.nn.ReLU()
        D = torch.nn.Dropout(0.2)

        task_loss = [0 for z in range(3)]
        task_acc = [0 for z in range(3)]

        task_prototypes = []

        for task_no, (task_support, task_query) in enumerate(zip(xs, xq)):
            prototypes = []
            for class_support in task_support:

                r = torch.stack([cs[0] for cs in class_support])
                t = torch.stack([cs[1] for cs in class_support])
                img = torch.stack([cs[2] for cs in class_support])
                encoded_vector = D(R(self.encoder(r, t, img)))
                z_projected = D(self.projector[task_no](D(R(self.connector[task_no](encoded_vector)))))
                prototype = z_projected.mean(0)
                prototypes.append(prototype)

            prototypes = torch.stack(prototypes)
            task_prototypes.append(prototypes)

            # query_target = [i for class_query in range(len(task_query)) for i in range(len(class_query))]
            # query_target = Variable(torch.tensor(query_target).long(), requires_grad=False).to(device)
          
            for query_no, class_query in enumerate(task_query):

                r = torch.stack([cq[0] for cq in class_query])
                t = torch.stack([cq[1] for cq in class_query])
                img = torch.stack([cq[2] for cq in class_query])
                
                encoded_vector = R(self.encoder(r, t, img))
                z_projected = self.projector[task_no](R(self.connector[task_no](encoded_vector)))
                dists = euclidean_dist(z_projected, prototypes)
                query_target = torch.ones((len(z_projected), 1)) * query_no
                query_target = Variable(query_target.long(), requires_grad=False).to(device)
                log_p_y = F.log_softmax(-dists, dim=1)
                loss_val = -log_p_y.gather(1, query_target).squeeze().view(-1).mean()

                _, y_hat = log_p_y.max(1)
                acc = torch.eq(y_hat, query_target.squeeze()).float().mean()

                task_loss[task_no] += loss_val
                task_acc[task_no] += acc
            
            task_loss[task_no] = task_loss[task_no] / len(task_query)
            task_acc[task_no] = task_acc[task_no] / len(task_query)

        return task_loss, task_acc, task_prototypes

    def testing(self, r, t, i, task_protos):

        R = torch.nn.ReLU()

        # Should match with ClientSampling.py
        task_name = ['Emotion', 'Sentiment', 'Complaint']
        all_pred = []

        for task_no in range(len(task_name)):
            prototype = task_protos[task_no]
            encoded_vector = R(self.encoder(r, t, i))
            z_projected = self.projector[task_no](R(self.connector[task_no](encoded_vector)))
            dists = euclidean_dist(z_projected, prototype)
            pred = torch.argmin(dists, dim = 1)
            all_pred.append(pred)

    def visualize(self, r, t, i, task_protos):

        R = torch.nn.ReLU()

        # Should match with ClientSampling.py
        task_name = ['Emotion', 'Sentiment', 'Complaint']
        z_proj = []

        for task_no in range(len(task_name)):
            prototype = task_protos[task_no]
            encoded_vector = R(self.encoder(r, t, i))
            z_proj.append(self.projector[task_no](R(self.connector[task_no](encoded_vector))).cpu().detach().numpy())

        return z_proj[0], z_proj[1], z_proj[2] 